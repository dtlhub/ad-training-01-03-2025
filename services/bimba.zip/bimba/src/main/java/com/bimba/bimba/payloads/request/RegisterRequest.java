package com.bimba.bimba.payloads.request;

public class RegisterRequest {
    
}
