package com.bimba.bimba.models;
import jakarta.validation.constraints.NotBlank;

public class Boyfrend {
    
    @NotBlank
    private String name;

    @NotBlank
    private String age;

    @NotBlank
    private Integer money; 
}
